| `Version`   | `Update Notes`                                                                                                                                                          |
|-------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.1.5       | - Added Force Show Changelog option                                                                                                                                     |
| 1.1.4       | - Moved Some Stuff around						                                                                                                                        |
| 1.1.3       | - Yep... Did an update                                                                                                                                                  |
| 1.1.2       | - Changed a Read Error to Warning                                                                                                                                       |
| 1.1.1       | - Deep North Update                                                                                                                                                     |
| 1.1.0       | - WackyMole Takeover                                                                                                                                                    |
| 1.0.9       | - Compile against latest, just in case.                                                                                                                                 |
| 1.0.8       | - Compile against Ashlands                                                                                                                                              |
| 1.0.7       | - Compile against Valheim 0.217.28                                                                                                                                      |
| 1.0.6       | - Fix some of the text not being taken literally and having escape characters.<br/> - Add a configuration option to change the width of the changelog (made by request) |
| 1.0.5       | - Update for latest Valheim version to show I checked.                                                                                                                  |
| 1.0.3/1.0.4 | - Update for Hildir's Request                                                                                                                                           |
| 1.0.2       | - ErDu's request to add in option to change the ChangLog title text                                                                                                     |
| 1.0.1       | - Toggle correctly                                                                                                                                                      |
| 1.0.0       | - Initial Release                                                                                                                                                       |